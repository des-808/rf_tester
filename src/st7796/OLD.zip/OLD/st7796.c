#include "st7796.h"
#include <string.h>

#include "stdint.h"
#include <stdbool.h>
#include <stdio.h>
#include "font.h"

extern SPI_HandleTypeDef hspi4;

bool bluetoothEnabled = true;
bool wifiEnabled = true;
bool ntpSyncEnabled = true;
bool buzzerOnOff = true;
bool bluetoothMode = true;
extern uint8_t screen_rotation;

// Буфер в кэшируемой памяти (не в .bss!)

uint8_t dma_buffer[320 * 2] __attribute__((section(".ram_d1"), aligned(32)));
// Буфер кадра в D1 RAM
 
uint16_t frame_buffer[320 * FRAME_BUFFER_HEIGHT] __attribute__((section(".ram_d1"), aligned(32)));
// Глобальный шрифт по умолчанию
uint16_t status_bar_frame_buffer[320*STATUS_BAR_HEIGHT] __attribute__((section(".ram_d1"), aligned(32)));

// В глобальных переменных
Sprite_t status_bar_sprite = {
    .data = status_bar_frame_buffer,
    .x = 0, .y = 0,
    .w = 320, .h = STATUS_BAR_HEIGHT
};

Sprite_t main_screen_sprite = {
    .data = frame_buffer,
    .x = 0, .y = STATUS_BAR_HEIGHT,
    .w = 320, .h = FRAME_BUFFER_HEIGHT
};

static void ST7796_WriteCmd(uint8_t cmd);
static void ST7796_WriteData(const uint8_t *data, size_t len);


/* void ST7796_TestRotation(void) {
    ST7796_FillScreen(0x0000); // чёрный
    
    // Рисуем белый круг в центре, разделённый на 4 цвета
    uint16_t cx = 160, cy = 240, r = 50;
    uint16_t colors[4] = {0xF800, 0x07E0, 0x001F, 0xFFFF}; // Красный, Зелёный, Синий, Белый
    
    for (int y = -r; y <= r; y++) {
        for (int x = -r; x <= r; x++) {
            if (x*x + y*y <= r*r) {
                // Определяем квадрант (четверть) точки (x, y)
                int quadrant = (y < 0) ? 0 : 2; // Верхняя (0) или нижняя (2) половина
                if (x >= 0) quadrant += 1;      // Правая половина добавляет 1
                
                ST7796_DrawPixel(cx + x, cy + y, colors[quadrant]);
            }
        }
    }
} */

static void ST7796_WriteCmd(uint8_t cmd) {
    LCD_CS_LOW;
    LCD_DC_CMD;
    HAL_SPI_Transmit(&hspi4, &cmd, 1, HAL_MAX_DELAY);
    LCD_CS_HIGH;
}

static void ST7796_WriteData(const uint8_t *data, size_t len) {
    LCD_CS_LOW;
    LCD_DC_DATA;

    HAL_SPI_Transmit_DMA(&hspi4, (uint8_t*)data, len);
    while (hspi4.State != HAL_SPI_STATE_READY);
    //HAL_SPI_Transmit(&hspi4, (uint8_t*)data, len, HAL_MAX_DELAY);
    LCD_CS_HIGH;
}

static void ST7796_WriteDataByte(uint8_t data) {
    LCD_CS_LOW;
    LCD_DC_DATA;
    HAL_SPI_Transmit(&hspi4, &data, 1, HAL_MAX_DELAY);
    LCD_CS_HIGH;
}

static HAL_StatusTypeDef ST7796_TransmitDMA(uint8_t *data, size_t len) {
    uint32_t size = (len + 31) & ~31;
    SCB_CleanDCache_by_Addr((uint32_t*)data, size);
    __DSB();  // ✅ Барьер синхронизации памяти
    HAL_StatusTypeDef status = HAL_SPI_Transmit_DMA(&hspi4, data, len);
    if (status != HAL_OK) {
        return status;
    }
    while (HAL_SPI_GetState(&hspi4) != HAL_SPI_STATE_READY) {
        /* wait for DMA completion */
    }
    return HAL_OK;
}

void ST7796_SetAddressWindow(uint16_t x, uint16_t y, uint16_t w, uint16_t h) {
    uint16_t xe = x + w - 1;
    uint16_t ye = y + h - 1;

    ST7796_WriteCmd(ST7796_CASET);
    uint8_t data[] = {x >> 8, x & 0xFF, xe >> 8, xe & 0xFF};
    ST7796_WriteData(data, 4);

    ST7796_WriteCmd(ST7796_PASET);
    data[0] = y >> 8; data[1] = y & 0xFF;
    data[2] = ye >> 8; data[3] = ye & 0xFF;
    ST7796_WriteData(data, 4);

    ST7796_WriteCmd(ST7796_RAMWR);
}

void ST7796_TestRotation(void) {
    // 1. Очистка буфера
    ST7796_ClearBuffer(0x0000);

    uint16_t cx = 160, cy = 240, r = 50;
    uint16_t colors[4] = {0xF800, 0x07E0, 0x001F, 0xFFFF};

    // 2. Рисуем круг (всегда в "портретных" координатах)
    for (int y = -r; y <= r; y++) {
        for (int x = -r; x <= r; x++) {
            if (x*x + y*y <= r*r) {
                int16_t rx = x, ry = y;
                switch (screen_rotation) {
                    case 1: rx = y; ry = -x; break;
                    case 2: rx = -x; ry = -y; break;
                    case 3: rx = -y; ry = x; break;
                }

                int quadrant = (ry < 0) ? 0 : 2;
                if (rx >= 0) quadrant += 1;

                int16_t px = cx + x;
                int16_t py = cy + y;
                if (px >= 0 && px < 320 && py >= 0 && py < 480) {
                    frame_buffer[py * 320 + px] = colors[quadrant];
                }
            }
        }
    }

    // 3. Рисуем текст под кругом
    // Текст: "ROT: X", где X = screen_rotation (0..3)
    char text[8];
    snprintf(text, sizeof(text), "ROT: %d", screen_rotation);
//lcd_print_to_buffer_ex(22, 32, RGB565_RED, "Привет!  МОЯ ЗАЙКА !!!",RGB565_BLACK,&main_screen_sprite,false);
    // Центрируем текст под кругом (y = cy + r + 20 = 240 + 50 + 20 = 310)
    uint16_t text_y = 310;
    lcd_set_font(&font_segoe_struct); // или другой шрифт, например &font_segoe_struct
    int16_t text_width = lcd_get_str_width(text);
    int16_t text_x = (320 - text_width) / 2;

    // Рисуем текст в frame_buffer
    lcd_print_to_buffer(text_x, text_y, RGB565_GREEN, text, RGB565_BLACK,&main_screen_sprite); // NULL — используем frame_buffer по умолчанию

    // 4. ✅ Отправляем полный кадр через DMA
    uint32_t frame_size = 320 * 480 * 2;
    SCB_CleanDCache_by_Addr((uint32_t*)frame_buffer, (frame_size + 31) & ~31);
    __DSB();

    ST7796_SetAddressWindow(0, 0, 320, 480);
    LCD_CS_LOW;
    LCD_DC_DATA;

    uint32_t row_size = 320 * 2;
    for (int y = 0; y < 480; y++) {
        memcpy(dma_buffer, &frame_buffer[y * 320], row_size);
        SCB_CleanDCache_by_Addr((uint32_t*)dma_buffer, 640);
        __DSB();
        if (ST7796_TransmitDMA(dma_buffer, row_size) != HAL_OK) break;
    }

    LCD_CS_HIGH;
}



void ST7796_DrawPixel(int16_t x, int16_t y, uint16_t color) {
    if (x < 0 || x >= 320 || y < 0 || y >= 480) return;
    //ST7796_SetAddressWindow(x, y, 1, 1);
    ST7796_SetAddressWindowRotated(x, y, 1, 1);
    uint8_t data[] = {color >> 8, color & 0xFF};
    ST7796_WriteData(data, 2);
}

void ST7796_FillScreen(uint16_t color) {
    //ST7796_SetAddressWindow(0, 0, 320, 480);
    ST7796_SetAddressWindowRotated(0, 0, 320, 480);
    uint8_t hi = color >> 8, lo = color & 0xFF;
    for (int i = 0; i < 320; i++) {
        dma_buffer[i*2] = hi;
        dma_buffer[i*2+1] = lo;
    }

    LCD_CS_LOW;
    LCD_DC_DATA;

    uint32_t len = 320 * 2;
    for (int y = 0; y < 480; y++) {
        if (ST7796_TransmitDMA(dma_buffer, len) != HAL_OK) {
            break;
        }
    }

    LCD_CS_HIGH;
}
void ST7796_FillScreenBlocking(uint16_t color) {
    ST7796_SetAddressWindow(0, 0, 320, 480);
    //ST7796_SetAddressWindowRotated(0, 0, 320, 480);
    uint8_t hi = color >> 8, lo = color & 0xFF;
    
    LCD_CS_LOW;
    LCD_DC_DATA;

    // Fill each line (480 rows)
    for (int y = 0; y < 480; y++) {
        // Process in chunks to avoid huge stack allocations
        const int CHUNK_SIZE = 128;  // 256 bytes per chunk
        uint8_t chunk[CHUNK_SIZE * 2];
        
        // Pre-fill chunk with repeated pixel data
        for (int i = 0; i < CHUNK_SIZE; i++) {
            chunk[i*2]   = hi;
            chunk[i*2+1] = lo;
        }

        // Send full chunks
        for (int i = 0; i < 320 / CHUNK_SIZE; i++) {
            HAL_SPI_Transmit(&hspi4, chunk, CHUNK_SIZE * 2, HAL_MAX_DELAY);
        }

        // Send remaining pixels
        int remaining = 320 % CHUNK_SIZE;
        if (remaining > 0) {
            HAL_SPI_Transmit(&hspi4, chunk, remaining * 2, HAL_MAX_DELAY);
        }
    }

    LCD_CS_HIGH;
}

uint8_t screen_rotation = 0; // 0 = portrait, 1 = landscape, 2 = portrait reversed, 3 = landscape reversed
void Sprite_set_rotation(uint8_t rotation) {
    screen_rotation = rotation % 4;

    // Пересчитываем размеры спрайтов для логики (важно для расчетов ширины текста и пр.)
    if (screen_rotation == 0 || screen_rotation == 2) {
        main_screen_sprite.w = 320;
        main_screen_sprite.h = FRAME_BUFFER_HEIGHT; // e.g. 480 - STATUS_BAR_HEIGHT
        status_bar_sprite.w = 320;
        status_bar_sprite.h = STATUS_BAR_HEIGHT;
    } else {
        main_screen_sprite.w = FRAME_BUFFER_HEIGHT;
        main_screen_sprite.h = 320;
        status_bar_sprite.w = STATUS_BAR_HEIGHT;
        status_bar_sprite.h = 320;
    }
}
void ST7796_SetRotation(uint8_t rotation) {
    ST7796_WriteCmd(ST7796_MADCTL);
    screen_rotation = rotation % 4;
    Sprite_set_rotation(screen_rotation);
    switch (screen_rotation) {
        case 0:
            ST7796_WriteDataByte(MADCTL_MX | MADCTL_BGR);
            break;
        case 1:
            ST7796_WriteDataByte(MADCTL_MV | MADCTL_BGR);
            break;
        case 2:
            ST7796_WriteDataByte(MADCTL_MY | MADCTL_BGR);
            break;
        case 3:
            ST7796_WriteDataByte(MADCTL_MX | MADCTL_MY | MADCTL_MV | MADCTL_BGR);
            break;
    }
}





void ST7796_SetAddressWindowRotated_OLD(int16_t x, int16_t y, uint16_t w, uint16_t h) {
    // Если портрет — просто вызываем обычную функцию
    if (screen_rotation == 0) {
        ST7796_SetAddressWindow(x, y, w, h);

        return;
    }

    // Для поворота 90° (landscape):
    // x' = y, y' = 319 - x - w + 1? — но проще:
    // Пусть экран логически 480×320 (landscape)
    // Но физически память — 320×480
    // Значит:
    int16_t rotated_x, rotated_y, rotated_w, rotated_h;
    switch (screen_rotation) {
        case 1: // 90°
            rotated_x = y;
            rotated_y = 319 - x - w;
            rotated_w = h;
            rotated_h = w;
            break;
        case 2: // 180°
            rotated_x = 319 - x - w;
            rotated_y = 479 - y - h;
            rotated_w = w;
            rotated_h = h;
            break;
        case 3: // 270°
            rotated_x = 479 - y - h;
            rotated_y = x;
            rotated_w = h;
            rotated_h = w;
            break;
        default:
            rotated_x = x;
            rotated_y = y;
            rotated_w = w;
            rotated_h = h;
            break;
    }
    ST7796_SetAddressWindow(rotated_x, rotated_y, rotated_w, rotated_h);
    
}

void ST7796_SetAddressWindowRotated(int16_t x, int16_t y, uint16_t w, uint16_t h) {
    // Если портрет — просто вызываем обычную функцию
    if (screen_rotation == 0) {
        ST7796_SetAddressWindow(x, y, w, h);
        return;
    }

    int16_t rotated_x, rotated_y, rotated_w, rotated_h;
    
    // Важно: физический размер экрана — 320×480
    // Логические размеры (с учётом поворота) обновляются в Sprite_set_rotation()
    switch (screen_rotation) {
        case 1: {  // 90° clockwise
            // x' = y, y' = 319 - x - w + 1? → проще: y' = 319 - x - (w - 1)
            rotated_x = y;
            rotated_y = 319 - x - w + 1;  // ✅ +1 correction!
            rotated_w = h;
            rotated_h = w;
            break;
        }
        case 2: {  // 180°
            rotated_x = 319 - x - w + 1;
            rotated_y = 479 - y - h + 1;
            rotated_w = w;
            rotated_h = h;
            break;
        }
        case 3: {  // 270° (counter-clockwise)
            rotated_x = 479 - y - h + 1;
            rotated_y = x;
            rotated_w = h;
            rotated_h = w;
            break;
        }
        default:
            rotated_x = x;
            rotated_y = y;
            rotated_w = w;
            rotated_h = h;
            break;
    }

    // Для safety
    if (rotated_x < 0) rotated_x = 0;
    if (rotated_y < 0) rotated_y = 0;
    // Можно добавить проверку на выход за границы, если нужно

    ST7796_SetAddressWindow(rotated_x, rotated_y, rotated_w, rotated_h);
}

uint16_t RGB565(uint8_t r, uint8_t g, uint8_t b) {
    uint16_t color = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
    // ✅ SWAP байтов для SPI
    return ((color & 0xFF) << 8) | ((color >> 8) & 0xFF);
}

uint16_t BGR565(uint8_t r, uint8_t g, uint8_t b) {
    uint16_t color = ((b & 0xF8) << 8) | ((g & 0xFC) << 3) | (r >> 3);
    // ✅ SWAP байтов для SPI
    return ((color & 0xFF) << 8) | ((color >> 8) & 0xFF);
}
 
void ST7796_Init(void) {
    // Инициализация frame_buffer
    ST7796_ClearBuffer(0x0000); // чёрный

    LCD_RESET_LOW;
    HAL_Delay(100);
    LCD_RESET_HIGH;
    HAL_Delay(150);

    ST7796_WriteCmd(ST7796_SWRESET);
    HAL_Delay(150);

    ST7796_WriteCmd(ST7796_SLPOUT);
    HAL_Delay(150);

    ST7796_WriteCmd(ST7796_COLMOD);
    ST7796_WriteDataByte(0x55);
    HAL_Delay(10);

    ST7796_WriteCmd(ST7796_MADCTL);
    ST7796_WriteDataByte(MADCTL_MX | MADCTL_BGR);

    ST7796_WriteCmd(ST7796_INVON);  // ← теперь выключено!

    ST7796_WriteCmd(ST7796_NORON);
    HAL_Delay(10);

    ST7796_WriteCmd(ST7796_DISPON);
    HAL_Delay(10);

    ST7796_FillScreen(RGB565_BLACK);
    //ST7796_FillScreenBlocking(RGB565(0, 0, 0)); // чёрный
}

void ST7796_DrawImage(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t *data) {
    //ST7796_SetAddressWindow(x, y, w, h);
    ST7796_SetAddressWindowRotated(x, y, w, h);
    LCD_CS_LOW;
    LCD_DC_DATA;

    uint32_t total_pixels = w * h;
    uint32_t sent = 0;
    uint32_t chunk_size;

    while (sent < total_pixels) {
        chunk_size = (total_pixels - sent > 320) ? 320 : (total_pixels - sent);
        memcpy(dma_buffer, &data[sent], chunk_size * 2);
        if (ST7796_TransmitDMA(dma_buffer, chunk_size * 2) != HAL_OK) {
            break;
        }

        sent += chunk_size;
    }

    LCD_CS_HIGH;
}

/* void ST7796_PrintCenter(uint16_t y, const char *str, uint16_t color, uint16_t bg, const Font_t *font) {
    int16_t len = strlen(str) * font->width;
    int16_t x = (320 - len) / 2;
    ST7796_Print(x, y, str, color, bg, font);
}  */

/* void lsd_print_centered(int16_t y, uint16_t color, const char *str) {
    int16_t width = lsd_get_str_width(str);
    int16_t start_x = (ST7796_WIDTH - width) / 2;
    lsd_print(start_x, y, color, str);
} */

void ST7796_ClearBuffer(uint16_t color) {
    uint32_t count = FRAME_BUFFER_WIDTH * FRAME_BUFFER_HEIGHT;
    for (uint32_t i = 0; i < count; i++) {
        frame_buffer[i] = color;
    }
}

void ST7796_FillBufferRect(uint16_t *buffer, uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color) {
    for (int dy = 0; dy < h; dy++) {
        uint32_t offset = (y + dy) * 320 + x;
        for (int dx = 0; dx < w; dx++) {
            buffer[offset + dx] = color;
        }
    }
}

void ST7796_UpdateScreenArea(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t *buffer) {
    if (!buffer || w == 0 || h == 0) return;
    if (x < 0 || y < 0 || x + w > 320 || y + h > 480) return; // проверка границ
    //ST7796_SetAddressWindow(x, y, w, h);
    ST7796_SetAddressWindowRotated(x, y, w, h);
    LCD_CS_LOW;
    LCD_DC_DATA;

    uint32_t total = w * h;
    uint32_t sent = 0;

    while (sent < total) {
        // Берём по одной строке (максимум w пикселей — ширина области!)
        uint32_t chunk = (total - sent > w) ? w : (total - sent);
        
        // Вычисляем позицию текущей строки в буфере
        uint32_t row_idx = sent / w;  // Номер строки в прямоугольнике
        uint32_t col_idx = sent % w;  // Позиция в строке
        
        // Адрес в буфере: (y + row_idx) * WIDTH + (x + col_idx)
        //uint32_t buffer_offset = (y + row_idx) * ST7796_WIDTH + (x + col_idx);// для 320x480
        // ✅ Работаем с произвольным `buffer`
        uint32_t buffer_offset = row_idx * w + col_idx;
        const uint16_t *src = &buffer[buffer_offset];

        // ✅ Очищаем кэш перед чтением из D1 RAM
        uint32_t size = (chunk * 2 + 31) & ~31;
        SCB_CleanDCache_by_Addr((uint32_t*)src, size);
        __DSB();  // Синхронизация памяти
        
        // Копируем в DMA буфер
        memcpy(dma_buffer, src, chunk * 2);
        
        // Отправляем через DMA
        if (ST7796_TransmitDMA(dma_buffer, chunk * 2) != HAL_OK) break;
        
        sent += chunk;
    }

    LCD_CS_HIGH;
}

void ST7796_DrawSprite(const Sprite_t *s) {
    if (!s || !s->data || s->w == 0 || s->h == 0) return;
    if (s->x + s->w > 320 || s->y + s->h > 480) return; // clipping

    // 1. Рисуем в frame_buffer
    for (uint16_t dy = 0; dy < s->h; dy++) {
        uint32_t dst_off = (s->y + dy) * 320 + s->x;
        uint32_t src_off = dy * s->w;
        memcpy(&frame_buffer[dst_off], &s->data[src_off], s->w * sizeof(uint16_t));
    }

    // 2. Отправляем только нужную область на экран
    ST7796_UpdateSprite(s);
}

void ST7796_UpdateSprite(const Sprite_t *s) {
    if (!s || !s->data || s->w == 0 || s->h == 0) return;
    if (s->x + s->w > 320 || s->y + s->h > 480) return;
    // Настройка окна
    //ST7796_SetAddressWindow(s->x, s->y, s->w, s->h);
    ST7796_SetAddressWindowRotated(s->x, s->y, s->w, s->h);
    LCD_CS_LOW;
    LCD_DC_DATA;
    // Отправка построчно (чтобы не тратить стек и RAM на huge memcpy)
    for (uint16_t dy = 0; dy < s->h; dy++) {
        const uint16_t *row = &s->data[dy * s->w];
        // Копируем в dma_buffer (кэшируемый буфер)
        memcpy(dma_buffer, row, s->w * sizeof(uint16_t));
        // ✅ Очищаем кэш перед отправкой — важно для D1 RAM!
        uint32_t size = (s->w * 2 + 31) & ~31;
        SCB_CleanDCache_by_Addr((uint32_t*)dma_buffer, size);
        __DSB();
        if (ST7796_TransmitDMA(dma_buffer, s->w * 2) != HAL_OK) break;
    }
    LCD_CS_HIGH;
}

// функция зеркалирования иконок
// Временный буфер для обработанной иконки (хватит для 16x16)
static uint8_t temp_icon_buffer[256]; 

// Функция горизонтального отзеркаливания (слева-направо)
const uint8_t* iconMirrorHorizontal(const unsigned char* bitmap, int w, int h) {
    int bytesPerRow = (w + 7) / 8;
    for (int j = 0; j < h; j++) {
        for (int i = 0; i < bytesPerRow; i++) {
            uint8_t b = bitmap[j * bytesPerRow + i];
            // Реверс бит в байте (для XBM-иконок)
            b = ((b & 0xF0) >> 4) | ((b & 0x0F) << 4);
            b = ((b & 0xCC) >> 2) | ((b & 0x33) << 2);
            b = ((b & 0xAA) >> 1) | ((b & 0x55) << 1);
            temp_icon_buffer[j * bytesPerRow + (bytesPerRow - 1 - i)] = b;
        }
    }
    return temp_icon_buffer;
}

// Функция вертикального отзеркаливания (верх-низ)
const uint8_t* iconMirrorVertical(const unsigned char* bitmap, int w, int h) {
    int bytesPerRow = (w + 7) / 8;
    for (int j = 0; j < h; j++) {
        for (int i = 0; i < bytesPerRow; i++) {
            temp_icon_buffer[(h - 1 - j) * bytesPerRow + i] = bitmap[j * bytesPerRow + i];
        }
    }
    return temp_icon_buffer;
}

// Глобальные переменные (как у тебя в ESP32)
extern int batteryLevel;
extern bool bluetoothEnabled, wifiEnabled, ntpSyncEnabled, buzzerOnOff, bluetoothMode;
extern uint8_t currentHour, currentMinute;

// Внешние иконки (примеры — см. ниже)
extern const uint8_t icon_battery_bits[];
extern const uint8_t icon_bluetooth_bits[];
extern const uint8_t icon_wifi_bits[];
extern const uint8_t icon_not_wifi_bits[];
extern const uint8_t icon_ntp_bits[];
extern const uint8_t icon_buzzer_on_bits[];
extern const uint8_t icon_buzzer_off_bits[];
extern const uint8_t icon_rs485ToBt_bits[];

uint8_t currentHour = 22;
uint8_t currentMinute = 43;
uint8_t battery_Level = 17;

/* void drawStatusBarOLD() {
    // 1. Очистка буфера статус-бара
    ST7796_FillBufferRect(status_bar_frame_buffer, 0, 0, ST7796_WIDTH, STATUS_BAR_HEIGHT, RGB565_BLACK);
    lcd_set_font(&font_arial_9_struct);// переключаем шрифт
    // --- Батарея ---
    char batBuf[8]; 
    snprintf(batBuf, sizeof(batBuf), "%d%%", battery_Level);
    int batWidth = lcd_get_str_width(batBuf);
    int curX = 158 - batWidth;

    // Текст батареи
    lcd_print_to_buffer(curX, 0, 0xFFFF, batBuf, 0x0000,);

    // --- Иконка батареи ---
    ST7796_DrawBitmap(curX - 10, 0, icon_battery_bits, 8, 8, 0xFFFF, 0x0000);

    // --- Bluetooth ---
    if (bluetoothEnabled) {
        const uint8_t* icon = iconMirrorHorizontal(icon_bluetooth_bits, 10, 8);
        ST7796_DrawBitmap(curX - 22, 0, icon, 10, 8, 0x001F, 0x0000);
    }

    // --- Wi-Fi ---
    bool wifiConnected = wifiEnabled;
    if (wifiConnected) {
        const uint8_t* icon = iconMirrorHorizontal(icon_wifi_bits, 10, 8);
        ST7796_DrawBitmap(curX - 34, 0, icon, 10, 8, 0x07E0, 0x0000);
    }

    // --- Auto NTP ---
    if (ntpSyncEnabled) {
        const uint8_t* icon = iconMirrorHorizontal(icon_ntp_bits, 8, 8);
        ST7796_DrawBitmap(curX - 48, 0, icon, 8, 8, 0xFFFF, 0x0000);
    }

    // --- Buzzer ---
    const uint8_t* icon_buzz = buzzerOnOff ? icon_buzzer_on_bits : icon_buzzer_off_bits;
    ST7796_DrawBitmap(curX - 62, 0, iconMirrorHorizontal(icon_buzz, 8, 8), 8, 8, 0xFFFF, 0x0000);

    // --- Bluetooth Mode (RS485→BT) ---
    const uint8_t* icon_bt_mode = iconMirrorHorizontal(icon_rs485ToBt_bits, 10, 8);
    ST7796_DrawBitmap(curX - 76, 0, icon_bt_mode, 10, 8, bluetoothMode ? 0x07E0 : 0x0000, 0x0000);

    // --- Время ---
    char timeBuf[6];
    snprintf(timeBuf,sizeof(timeBuf), "%02d:%02d", currentHour, currentMinute);
    lcd_print_to_buffer(0, 0, 0xFFFF, timeBuf, 0x0000);

    // 2. Отправить буфер статус-бара на экран
    ST7796_UpdateScreenArea(0, 0, 320, STATUS_BAR_HEIGHT, status_bar_frame_buffer);
} */

void drawStatusBar(Sprite_t *sprite) {
    lcd_set_font(&font_segoe_struct);
    // 1. Очистка буфера статус-бара
    //ST7796_FillBufferRect(status_bar_frame_buffer, 0, 0, sprite->w, sprite->h, RGB565_BLACK);
    ST7796_FillBufferRect(sprite->data, 0, 0, sprite->w, sprite->h, RGB565_BLACK);
    // --- Время ---
    char timeBuf[6];
    snprintf(timeBuf,sizeof(timeBuf), "%02d:%02d", currentHour, currentMinute);
    lcd_print_to_buffer(0, 4, 0xFFFF, timeBuf, 0x0000,sprite);

    lcd_set_font(&font_arial_9_struct);// переключаем шрифт
    // --- Батарея ---
    char batBuf[8]; 
    snprintf(batBuf, sizeof(batBuf), "%d%%", battery_Level);
    int batWidth = lcd_get_str_width(batBuf);
    int curX = 318 - batWidth;

    // Текст батареи
    lcd_print_to_buffer_ex(curX, 4, 0xFFFF, batBuf, 0x0000,sprite,false);

    // --- Иконка батареи ---
    ST7796_DrawBitmap(curX - 10, 4, icon_battery_16_16_bits, 16, 16, 0xFFFF, 0x0000,sprite->data);
    

    // --- Bluetooth ---
    if (bluetoothEnabled) {
        const uint8_t* icon = iconMirrorHorizontal(icon_bluetooth_bits, 10, 8);
        ST7796_DrawBitmap(curX - 32, 4, icon, 10, 8, 0x001F, 0x0000,sprite->data);
    }

    // --- Wi-Fi ---
    bool wifiConnected = wifiEnabled;
    if (wifiConnected) {
        const uint8_t* icon = iconMirrorHorizontal(icon_wifi_bits, 10, 8);
        ST7796_DrawBitmap(curX - 44, 4, icon, 10, 8, 0x07E0, 0x0000,sprite->data);
    }

    // --- Auto NTP ---
    if (ntpSyncEnabled) {
        const uint8_t* icon = iconMirrorHorizontal(icon_ntp_bits, 8, 8);
        ST7796_DrawBitmap(curX - 58, 4, icon, 8, 8, 0xFFFF, 0x0000,sprite->data);
    }

    // --- Buzzer ---
    const uint8_t* icon_buzz = buzzerOnOff ? icon_buzzer_on_bits : icon_buzzer_off_bits;
    ST7796_DrawBitmap(curX - 72, 4, iconMirrorHorizontal(icon_buzz, 8, 8), 8, 8, 0xFFFF, 0x0000,sprite->data);

    // --- Bluetooth Mode (RS485→BT) ---
    const uint8_t* icon_bt_mode = iconMirrorHorizontal(icon_rs485ToBt_bits, 10, 8);
    ST7796_DrawBitmap(curX - 86, 4, icon_bt_mode, 10, 8, bluetoothMode ? 0x07E0 : 0x0000, 0x0000,sprite->data);

    

    // 2. Отправить буфер статус-бара на экран
    //ST7796_UpdateScreenArea(0, 0, sprite->w,sprite->h, status_bar_sprite.data);
    //ST7796_UpdateScreenArea(0, 0, sprite->w,sprite->h, sprite->data);
    //ST7796_UpdateSpriteArea(0, 0, sprite->w,sprite->h, sprite);
    ST7796_UpdateSprite(sprite);
}

// ✅ Реализация ST7796_DrawBitmap — отрисовка битовой маски (XBM)
void ST7796_DrawBitmap(int16_t x, int16_t y, const uint8_t *bitmap, uint16_t w, uint16_t h, uint16_t fgColor, uint16_t bgColor,uint16_t *buffer) {
    if (x < 0 || y < 0 || x + w > 320 || y + h > 480) return;

    // Пример: иконка 8x8 — значит, 8 байт на строку (если w=8, то bytesPerRow = 1)
    for (uint16_t row = 0; row < h; row++) {
        uint16_t byte_idx = row * ((w + 7) / 8);
        for (uint16_t col = 0; col < w; col++) {
            uint8_t mask = 0x80 >> (col % 8);  // биты: MSB слева
            uint8_t bit = (bitmap[byte_idx + col / 8] & mask);

            // Если структура XBM: 1 бит = 1 пиксель
            uint32_t idx = (y + row) * 320 + (x + col);
            if (bit) {
                buffer[idx] = fgColor;
            } else if (bgColor != 0xFFFF) {
                buffer[idx] = bgColor;
            }
        }
    }

    // Отрисовка на экране (только область)
    ST7796_UpdateScreenArea(x, y, w, h, buffer);
}

void ST7796_UpdateSpriteArea(uint16_t x, uint16_t y, uint16_t w, uint16_t h ,const Sprite_t *sprite) {
    // x, y — координаты ВНУТРИ спрайта
    ST7796_UpdateScreenArea(sprite->x + x, sprite->y + y, w, h, sprite->data);
}




void lcd_update_sprite_full(const Sprite_t* sprite) {
    SCB_CleanDCache_by_Addr((uint32_t*)sprite->data, (sprite->w * sprite->h * 2 + 31) & ~31);
    __DSB();
    ST7796_UpdateSprite(sprite);  // ← обновляет весь спрайт
}
